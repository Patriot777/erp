from django.apps import AppConfig


class MycompanyConfig(AppConfig):
    name = 'mycompany'
