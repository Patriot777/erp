from django.contrib import admin
from .models import Profile, myProject

admin.site.register(Profile)
admin.site.register(myProject)
# Register your models here.
