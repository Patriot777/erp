from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.contrib.auth import get_user_model

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    myrole = models.CharField(max_length=5, default="user")
    image = models.ImageField(default='default.jpg', upload_to='profile_pics')

    def __str__(self):
        return f'{self.user.username} Profile'

class myProject(models.Model):
    title = models.CharField(max_length=40)
    text = models.TextField(max_length=2000)
    myfile = models.FileField(default='', upload_to='project')
    organization = models.CharField(max_length=100)
    startDateProject = models.DateField(auto_now=True)
    endDateProject = models.DateField(auto_now=True)
    roleUser = models.CharField(max_length=40)
    skills = models.TextField(blank=True, default="-")
    TypeProject = models.CharField(max_length=100)
    link = models.CharField(max_length=200)
    author = models.ForeignKey(get_user_model(), on_delete=models.CASCADE,)
    createDateProject = models.DateField(auto_now=True)
    updateDateProject = models.DateField(auto_now=True)
    def __str__(self):
        return self.title

