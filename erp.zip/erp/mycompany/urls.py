from django.urls import path, include
from . import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('', views.index, name="index"),
    path('/accounts/login/', views.login, name="login"),
    path('/accounts/logout/', views.logout, name="logout"),
    path('/profile/', views.profile, name="profile"),
    path('/profile/editProfile/', views.editProfile, name="editProfile"),
    path('/profile/createproject/', views.createProject, name="createProject"),
    path('/profile/<int:idt>', views.projectEdit, name="project_edit"), 
    path('/projectdetail/<int:idb>/', views.projectDetail, name="project_detail") ,  
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
