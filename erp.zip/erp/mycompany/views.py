from .models import Profile, myProject
from django.shortcuts import render
from django.http import HttpResponse
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.shortcuts import redirect
from django.contrib.auth import get_user_model
from django.core.files.storage import FileSystemStorage
import xlrd
import datetime
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger




def index(request):
    pageOne = myProject.objects.all()
    
    
    return render(request, 'index.html', {'pageOne': pageOne})

def login(request):
    return render(request, 'login.html')

def logout(request):
    return render(request, 'logged_out.html')

def profile(request):
     
    if request.user.is_authenticated:
        if request.method == "POST" and 'my_project_file' in request.POST:
            myfile2 = request.FILES['file_project']         
            quser = User.objects.get(username = request.user.username)   #Обєкт поточного користувача
            fs = FileSystemStorage(location='media/projects/', base_url='media/projects/')
            filename = fs.save(myfile2.name, myfile2)
            myurl = fs.url(filename) 

            #Робота з таблицею EXEL
            iwb = xlrd.open_workbook(myurl)
            iws = iwb.sheet_by_index(0)
            TitleUserProject = iws.cell_value(0,1)              #Назва проекту
            DescriptionUserProject = iws.cell_value(1,1)        #Опис проекту
            OrganizationUser = iws.cell_value(2, 1)             #Організація
            RoleUser = iws.cell_value(3,1)                      #Роль
            SkillsUser = iws.cell_value(4,1)                    #Навички
            TypeProject = iws.cell_value(5,1)                   #Тип проекту
            LinkProject = iws.cell_value(6,1)                   #Посилання 

            print(DescriptionUserProject)
            #Запис інформації з таблиці в базу данних
            myProject.objects.create(title = TitleUserProject, text=DescriptionUserProject, myfile = myfile2, author = quser, organization = OrganizationUser, roleUser = RoleUser, skills = SkillsUser, TypeProject =  TypeProject, link = LinkProject)
        author = User.objects.get(username = request.user.username)   #Обєкт поточного користувача
        MyProjectGet = myProject.objects.filter(author = author)
        myUser = Profile.objects.filter(user = author)
        mpg = MyProjectGet #Проекти автора

    return render(request, 'profile.html', {'mpg': mpg, 'myUser': myUser})



#Функція редагування профілю
def editProfile(request):

    if request.user.is_authenticated:               
        if request.method == "POST" and 'mybtnText' in request.POST:
            myfirst_name = request.POST.get('my_first_name')
            mylast_name = request.POST.get('my_last_name')
            myEmail = request.POST.get('my_email')
            if mylast_name:
                User.objects.filter(username = request.user.username).update(last_name = mylast_name)   
            if myfirst_name:
                User.objects.filter(username = request.user.username).update(first_name = myfirst_name)
            if myEmail:
                User.objects.filter(username = request.user.username).update(email = myEmail)
        
        if request.method == "POST" and 'mybtnImage' in request.POST:
            myfile = request.FILES['my_image']
            Profile.objects.filter(user = request.user).update(image=myfile)
            fs = FileSystemStorage(location=None)
            filename = fs.save(myfile.name, myfile)
            uploaded_file_url = fs.url(filename)
    
    return render(request, 'editprofile.html')



#Функція створення проекту
def createProject(request):
    if request.user.is_authenticated:
        if request.method == "POST" and request.FILES['my_image']:
            myfile = request.FILES['my_image']
            Profile.objects.filter(user = request.user).update(image=myfile)
            fs = FileSystemStorage()
            filename = fs.save(myfile.name, myfile)
            uploaded_file_url = fs.url(filename)
            #quser = User.objects.get(username = request.user.username)
            #myProject.objects.create(title = projectTitle, text = " hello ", author = quser)
            
            #print(projectTitle)
    return render(request, 'create_project.html')


def projectEdit(request, idt):
    editProjectUser = myProject.objects.filter(id = idt)
    
    if request.user.is_authenticated:  
        timeNow = datetime.datetime.now()  #Отримав поточну дату та час
        currentMonth = timeNow.month
        currentDay = timeNow.day
        currentYear = timeNow.year
        currentDate = str(currentYear) + "-" + str(currentMonth) + "-" + str(currentDay)
        
        
        if request.method == "POST":
            NewTitleProject = request.POST.get('new_title')
            NewTextProject = request.POST.get('new_text')
            NewOrganization = request.POST.get('new_organization')
            NewDataStartProject = request.POST.get('new_start_date_project')
            EndDataStartProject = request.POST.get('end_start_date_project')
            skills = request.POST.get('skills')
            typeProject = request.POST.get('type_project')
            link = request.POST.get('link')

            myProject.objects.filter(id = idt).update(updateDateProject = currentDate)
            if NewTitleProject:
                myProject.objects.filter(id = idt).update(title = NewTitleProject)
            if NewTextProject:
                myProject.objects.filter(id = idt).update(text = NewTextProject)
            if NewOrganization:
                myProject.objects.filter(id = idt).update(organization = NewOrganization)
            if NewDataStartProject:
                myProject.objects.filter(id = idt).update(startDateProject = NewDataStartProject)
            if EndDataStartProject:
                myProject.objects.filter(id = idt).update(endDateProject = EndDataStartProject)
            if skills:
                myProject.objects.filter(id = idt).update(skills = skills)
            if typeProject:
                myProject.objects.filter(id = idt).update(TypeProject = typeProject)
            if link:
                myProject.objects.filter(id = idt).update(link = link) 

        #Обробляє кнопку видалення
        if request.method == "POST" and 'delm' in request.POST:
            ip = myProject.objects.filter(id = idt)
            ip.delete()
            
            profile(request)
    return render(request, 'editproject.html', {'editProjectUser': editProjectUser})
    

def projectDetail(request, idb):
    author = User.objects.get(username = request.user.username)
    myAdmin = Profile.objects.filter(user = author)
    detailProjectUser = myProject.objects.filter(id = idb)
    if request.method == "POST" and 'dela' in request.POST:
            ip = myProject.objects.filter(id = idb)
            ip.delete()
    return render(request, 'detailproject.html', {'detailProjectUser': detailProjectUser, 'myAdmin': myAdmin})
